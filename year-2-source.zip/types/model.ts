export type MachineReference = {
  id: string;
  name: string;
  capacity: number;
  purchasePrice: number;
  maintenance: number;
  depreciation: number;
};

export type PremiseReference = {
  id: string;
  machineSlots: number;
  rent: number;
  transportRate: number;
  possibleStorage: boolean;
};

export type OwnedMachine = MachineReference & {
  instanceId: string;
  remainingLife: number;
  available: boolean;
};

export type ExistingLoan = {
  id: string;
  label: string;
  outstandingPrincipal: number;
  remainingTerm: number;
  interestRate: number;
  scheduledPrincipalPayment: number;
};

export type HistoricalPosition = {
  closingCash: number | null;
  annualNetProfit: number | null;
  taxLossCarryforward: number | null;
  loansConfirmed: boolean;
  machinesConfirmed: boolean;
  loans: ExistingLoan[];
  machines: OwnedMachine[];
};

export type PremisePlan = PremiseReference & {
  selected: boolean;
  production: number;
};

export type MachinePurchase = MachineReference & {
  instanceId: string;
  used: boolean;
};

export type ScenarioInput = {
  id: "a" | "b";
  name: string;
  plannedProduction: number;
  milkTons: number;
  milkCostPerTon: number;
  milkYieldPerTon: number;
  requestedSales: number;
  actualAllocation: number;
  sellingPrice: number;
  marketInvestment: number;
  premises: PremisePlan[];
  usedOwnedMachineIds: string[];
  machinePurchases: MachinePurchase[];
  borrowingAmount: number;
  loanTerm: number;
  interestRate: number;
  fixedSalaries: number;
  bonusRate: number;
  taxRate: number;
};

export type LoanResult = {
  received: number;
  principalRepaid: number;
  interest: number;
  endingDebt: number;
};

export type TaxResult = {
  lossPoolUsed: number;
  taxableProfit: number;
  tax: number;
  endingLossPool: number;
};

export type TransportAllocation = {
  premiseId: string;
  production: number;
  soldUnits: number;
  rate: number;
  cost: number;
};

export type ScenarioResult = {
  testedAllocation: number;
  revenue: number;
  milkCost: number;
  maintenance: number;
  depreciation: number;
  grossProfit: number;
  transport: number;
  marketInvestment: number;
  employeeBonus: number;
  fixedSalaries: number;
  rent: number;
  loanInterest: number;
  profitBeforeTax: number;
  taxLossPoolUsed: number;
  taxableProfit: number;
  tax: number;
  netProfit: number;
  endingTaxLossCarryforward: number;
  openingCash: number;
  newBorrowing: number;
  machinePurchases: number;
  loanPrincipal: number;
  cashBeforeAdvancePayments: number;
  closingCash: number;
  endingDebt: number;
  unitsSold: number;
  unsoldIceCream: number;
  unusedMilk: number;
  spoilageExposure: number;
  activeMachineCapacity: number;
  machineCountUsed: number;
  machineSlots: number;
  transportAllocation: TransportAllocation[];
  warnings: string[];
  missingHistory: string[];
  breakEvenSalesAllocation: number | null;
  minimumAllocationForNonNegativeCash: number | null;
};

export type DecisionRecord = {
  selectedStrategy: string;
  mainAssumption: string;
  expectedTrainerAllocation: string;
  mainRisk: string;
  lowerAllocationOutcome: string;
  reason: string;
};

export type AppState = {
  version: 1;
  year1: HistoricalPosition;
  scenarios: [ScenarioInput, ScenarioInput];
  sensitivity: [number, number];
  decision: DecisionRecord;
  validation: {
    scenarioId: "a" | "b";
    expectedNetProfit: number | null;
    expectedClosingCash: number | null;
  };
};
