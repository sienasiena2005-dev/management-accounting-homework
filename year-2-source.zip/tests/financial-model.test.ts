import assert from "node:assert/strict";
import test from "node:test";
import { MACHINE_REFERENCES, PREMISE_REFERENCES } from "../data/year1Reference.ts";
import { calculateScenario } from "../lib/calculations.ts";
import { calculateLoans } from "../lib/loans.ts";
import { calculateTax } from "../lib/tax.ts";
import { allocateTransport } from "../lib/transport.ts";
import type { HistoricalPosition, ScenarioInput } from "../types/model.ts";

const machine5 = MACHINE_REFERENCES.find((machine) => machine.id === "machine-5")!;
function workedExample(): { history: HistoricalPosition; scenario: ScenarioInput } {
  return {
    history: {
      closingCash: 100_000,
      annualNetProfit: 0,
      taxLossCarryforward: 0,
      loansConfirmed: true,
      machinesConfirmed: true,
      loans: [],
      machines: [],
    },
    scenario: {
      id: "a",
      name: "Year 1 worked example",
      plannedProduction: 40_000,
      milkTons: 2,
      milkCostPerTon: 20_000,
      milkYieldPerTon: 20_000,
      requestedSales: 40_000,
      actualAllocation: 40_000,
      sellingPrice: 2,
      marketInvestment: 1_000,
      premises: PREMISE_REFERENCES.map((premise) => ({
        ...premise,
        selected: premise.id === "B",
        production: premise.id === "B" ? 40_000 : 0,
      })),
      usedOwnedMachineIds: [],
      machinePurchases: [{ ...machine5, instanceId: "worked-example-machine-5", used: true }],
      borrowingAmount: 0,
      loanTerm: 1,
      interestRate: 0.1,
      fixedSalaries: 10_000,
      bonusRate: 0.05,
      taxRate: 0.1,
    },
  };
}

test("official Year 1 worked example reconciles P&L and cash", () => {
  const { history, scenario } = workedExample();
  const result = calculateScenario(scenario, history);
  assert.equal(result.grossProfit, 35_200);
  assert.equal(result.employeeBonus, 1_760);
  assert.equal(result.profitBeforeTax, -3_560);
  assert.equal(result.tax, 0);
  assert.equal(result.netProfit, -3_560);
  assert.equal(result.closingCash, 71_940);
  assert.equal(result.endingTaxLossCarryforward, 3_560);
});

test("capital purchases stay out of P&L and depreciation stays out of cash", () => {
  const { history, scenario } = workedExample();
  const base = calculateScenario(scenario, history);
  const expensivePurchase = {
    ...scenario,
    machinePurchases: [{ ...scenario.machinePurchases[0], purchasePrice: 128_000 }],
  };
  const changed = calculateScenario(expensivePurchase, history);
  assert.equal(changed.netProfit, base.netProfit);
  assert.equal(changed.closingCash, base.closingCash - 100_000);
});

test("loan principal stays out of P&L while interest affects P&L and cash", () => {
  const loans = calculateLoans([], 100_000, 4, 0.1);
  assert.deepEqual(loans, { received: 100_000, principalRepaid: 25_000, interest: 10_000, endingDebt: 75_000 });
});

test("tax losses offset positive profit before tax", () => {
  assert.deepEqual(calculateTax(25_000, 10_000, 0.1), {
    lossPoolUsed: 10_000,
    taxableProfit: 15_000,
    tax: 1_500,
    endingLossPool: 0,
  });
});

test("transport allocation uses whole units and assigns residual to final premise", () => {
  const allocations = allocateTransport([
    { ...PREMISE_REFERENCES[0], selected: true, production: 1 },
    { ...PREMISE_REFERENCES[1], selected: true, production: 2 },
  ], 10);
  assert.equal(allocations[0].soldUnits, 3);
  assert.equal(allocations[1].soldUnits, 7);
  assert.equal(allocations.reduce((sum, row) => sum + row.soldUnits, 0), 10);
});

test("lower allocation increases unsold inventory and reduces revenue", () => {
  const { history, scenario } = workedExample();
  const full = calculateScenario(scenario, history, 100);
  const downside = calculateScenario(scenario, history, 50);
  assert.equal(downside.revenue, full.revenue / 2);
  assert.equal(downside.unsoldIceCream, 20_000);
  assert.ok(downside.closingCash < full.closingCash);
});
