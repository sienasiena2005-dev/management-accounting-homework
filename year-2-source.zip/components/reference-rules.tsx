import { AlertCircle } from "lucide-react";
import { MACHINE_REFERENCES, PREMISE_REFERENCES } from "../data/year1Reference.ts";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export function ReferenceRules() {
  return (
    <Card className="border-amber-200 bg-amber-50/55 shadow-none">
      <CardContent className="pt-0">
        <Accordion type="single" collapsible>
          <AccordionItem value="rules">
            <AccordionTrigger className="py-5 text-base text-amber-950"><span className="flex items-center gap-2"><AlertCircle className="size-4" />ESTIMATE — Year 1 reference rules, editable in each scenario</span></AccordionTrigger>
            <AccordionContent className="space-y-5 text-amber-950">
              <p className="max-w-4xl leading-6">Official Year 2 rules have not been provided. These values are Year 1 references only. Premises A, B and F were flagged as possibly relevant to storage, but no Year 2 storage mechanism has been invented.</p>
              <div className="grid gap-5 xl:grid-cols-2">
                <div className="overflow-x-auto rounded-xl border border-amber-200 bg-white">
                  <Table><TableHeader><TableRow><TableHead>Premise</TableHead><TableHead>Slots</TableHead><TableHead>Rent</TableHead><TableHead>Transport</TableHead></TableRow></TableHeader><TableBody>{PREMISE_REFERENCES.map((premise) => <TableRow key={premise.id}><TableCell className="font-semibold">{premise.id}{premise.possibleStorage ? "*" : ""}</TableCell><TableCell>{premise.machineSlots}</TableCell><TableCell>Sh {premise.rent.toLocaleString()}</TableCell><TableCell>Sh {premise.transportRate}</TableCell></TableRow>)}</TableBody></Table>
                </div>
                <div className="overflow-x-auto rounded-xl border border-amber-200 bg-white">
                  <Table><TableHeader><TableRow><TableHead>Machine</TableHead><TableHead>Capacity</TableHead><TableHead>Purchase</TableHead><TableHead>Maint.</TableHead><TableHead>Deprec.</TableHead></TableRow></TableHeader><TableBody>{MACHINE_REFERENCES.map((machine) => <TableRow key={machine.id}><TableCell className="font-semibold">{machine.name}</TableCell><TableCell>{machine.capacity.toLocaleString()}</TableCell><TableCell>Sh {machine.purchasePrice.toLocaleString()}</TableCell><TableCell>Sh {machine.maintenance.toLocaleString()}</TableCell><TableCell>Sh {machine.depreciation.toLocaleString()}</TableCell></TableRow>)}</TableBody></Table>
                </div>
              </div>
              <p className="text-xs">* Possible Year 2 storage relevance only. Storage costs, capacity and mechanics remain unknown.</p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}
