"use client";

import { useState } from "react";
import { AlertTriangle, CirclePlus, Coins, Factory, Landmark, ShoppingCart, Trash2, TrendingDown } from "lucide-react";
import { MACHINE_REFERENCES, MARKET_FORECAST } from "../data/year1Reference.ts";
import type { HistoricalPosition, ScenarioInput, ScenarioResult } from "../types/model.ts";
import { NumberField } from "./number-field";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { Slider } from "@/components/ui/slider";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const money = (value: number) => `Sh ${value.toLocaleString()}`;
const units = (value: number) => value.toLocaleString();

function newId(prefix: string) {
  return `${prefix}-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`;
}

function Metric({ label, value, tone = "neutral", note }: { label: string; value: string; tone?: "neutral" | "good" | "bad" | "special"; note?: string }) {
  const styles = {
    neutral: "border-slate-200 bg-slate-50",
    good: "border-emerald-200 bg-emerald-50",
    bad: "border-red-200 bg-red-50",
    special: "border-violet-200 bg-violet-50",
  }[tone];
  return (
    <div className={`rounded-xl border p-3.5 ${styles}`}>
      <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-slate-500">{label}</p>
      <p className="mt-1.5 text-xl font-semibold tracking-tight text-slate-950">{value}</p>
      {note ? <p className="mt-1 text-xs text-slate-500">{note}</p> : null}
    </div>
  );
}

function StatementRow({ label, value, strong = false, unavailable = false }: { label: string; value: number; strong?: boolean; unavailable?: boolean }) {
  return (
    <div className={`flex items-center justify-between gap-3 py-2 text-sm ${strong ? "border-t border-slate-300 pt-3 font-semibold" : "text-slate-600"}`}>
      <span>{label}</span><span className="tabular-nums text-slate-950">{unavailable ? "—" : money(value)}</span>
    </div>
  );
}

export function ScenarioPanel({
  scenario,
  history,
  result,
  sensitivity,
  onChange,
  onSensitivityChange,
}: {
  scenario: ScenarioInput;
  history: HistoricalPosition;
  result: ScenarioResult;
  sensitivity: number;
  onChange: (next: ScenarioInput) => void;
  onSensitivityChange: (next: number) => void;
}) {
  const [purchaseReferenceId, setPurchaseReferenceId] = useState(MACHINE_REFERENCES[0].id);
  const accent = scenario.id === "a" ? "bg-[#13233f]" : "bg-[#0f766e]";
  const taxUnavailable = history.taxLossCarryforward === null;
  const cashUnavailable = history.closingCash === null || taxUnavailable;
  const debtUnavailable = !history.loansConfirmed;

  function patch<K extends keyof ScenarioInput>(key: K, value: ScenarioInput[K]) {
    onChange({ ...scenario, [key]: value });
  }

  function addPurchase() {
    const reference = MACHINE_REFERENCES.find((machine) => machine.id === purchaseReferenceId)!;
    patch("machinePurchases", [...scenario.machinePurchases, { ...reference, instanceId: newId("purchase"), used: true }]);
  }

  return (
    <Card className="overflow-hidden border-slate-200 bg-white shadow-[0_14px_40px_rgba(15,23,42,0.06)]">
      <div className={`h-1.5 ${accent}`} />
      <CardHeader className="gap-4 border-b border-slate-100 pb-5">
        <div className="flex items-center justify-between gap-3">
          <span className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Option {scenario.id.toUpperCase()}</span>
          <span className="rounded-full bg-amber-50 px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-amber-800">Estimates editable</span>
        </div>
        <Input aria-label={`Option ${scenario.id.toUpperCase()} name`} value={scenario.name} onChange={(event) => patch("name", event.target.value)} className="h-auto border-0 px-0 text-2xl font-semibold tracking-tight shadow-none focus-visible:ring-0" />
        {result.missingHistory.length ? (
          <div className="rounded-xl border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
            <strong>Historical inputs needed:</strong> {result.missingHistory.join(", ")}. Profit-before-tax and operating metrics still calculate; dependent values show as unavailable.
          </div>
        ) : null}
      </CardHeader>
      <CardContent className="space-y-5 pt-5">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Metric label="Net profit" value={taxUnavailable ? "—" : money(result.netProfit)} tone={!taxUnavailable && result.netProfit >= 0 ? "good" : !taxUnavailable ? "bad" : "neutral"} />
          <Metric label="Closing cash" value={cashUnavailable ? "—" : money(result.closingCash)} tone={!cashUnavailable && result.closingCash >= 0 ? "good" : !cashUnavailable ? "bad" : "neutral"} />
          <Metric label="Actual sales" value={units(result.unitsSold)} tone="special" note={`of ${units(scenario.actualAllocation)} base`} />
          <Metric label="Advance cash" value={history.closingCash === null ? "—" : money(result.cashBeforeAdvancePayments)} tone={history.closingCash === null ? "neutral" : result.cashBeforeAdvancePayments >= 0 ? "good" : "bad"} />
          <Metric label="Spoilage exposure" value={`${units(result.spoilageExposure)} units`} tone={result.spoilageExposure > 0 ? "bad" : "good"} />
          <Metric label="Debt remaining" value={debtUnavailable ? "—" : money(result.endingDebt)} />
        </div>

        {result.warnings.length ? (
          <div className="rounded-xl border border-red-200 bg-red-50 p-4">
            <p className="flex items-center gap-2 text-sm font-semibold text-red-900"><AlertTriangle className="size-4" />Plan warnings</p>
            <ul className="mt-2 space-y-1 pl-5 text-sm text-red-800">
              {result.warnings.map((warning) => <li key={warning} className="list-disc">{warning}</li>)}
            </ul>
          </div>
        ) : (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm font-medium text-emerald-800">No model constraint warnings at the current inputs.</div>
        )}

        <Accordion type="multiple" defaultValue={["operations", "sales"]} className="rounded-xl border border-slate-200 px-4">
          <AccordionItem value="operations">
            <AccordionTrigger className="text-base"><span className="flex items-center gap-2"><Factory className="size-4 text-slate-500" />Production, premises &amp; machines</span></AccordionTrigger>
            <AccordionContent className="space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <NumberField id={`${scenario.id}-production`} label="Planned production" suffix="units" value={scenario.plannedProduction} onChange={(next) => patch("plannedProduction", next ?? 0)} />
                <NumberField id={`${scenario.id}-milk-tons`} label="Milk purchased" suffix="tons" value={scenario.milkTons} step={0.1} tone="estimate" onChange={(next) => patch("milkTons", next ?? 0)} />
                <NumberField id={`${scenario.id}-milk-cost`} label="Milk cost / ton" prefix="Sh" value={scenario.milkCostPerTon} tone="estimate" onChange={(next) => patch("milkCostPerTon", next ?? 0)} />
                <NumberField id={`${scenario.id}-milk-yield`} label="Milk yield / ton" suffix="units" value={scenario.milkYieldPerTon} tone="estimate" hint="Worked-example reference only; official Year 2 yield is not known." onChange={(next) => patch("milkYieldPerTon", next ?? 0)} />
              </div>

              <div>
                <div className="mb-2 flex items-center justify-between"><h4 className="text-sm font-semibold">Premise plan</h4><span className="text-xs text-amber-700">ESTIMATE — Year 1 reference, editable</span></div>
                <div className="space-y-2">
                  {scenario.premises.map((premise) => (
                    <div key={premise.id} className={`rounded-xl border p-3 ${premise.selected ? "border-amber-200 bg-amber-50/60" : "border-slate-200 bg-slate-50"}`}>
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <Checkbox id={`${scenario.id}-premise-${premise.id}`} checked={premise.selected} onCheckedChange={(checked) => patch("premises", scenario.premises.map((item) => item.id === premise.id ? { ...item, selected: Boolean(checked) } : item))} />
                          <Label htmlFor={`${scenario.id}-premise-${premise.id}`} className="font-semibold">Premise {premise.id}</Label>
                          {premise.possibleStorage ? <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-semibold text-blue-800">Possible storage</span> : null}
                        </div>
                        <span className="text-xs text-slate-500">{premise.machineSlots} slot{premise.machineSlots === 1 ? "" : "s"}</span>
                      </div>
                      {premise.selected ? (
                        <div className="mt-3 grid gap-3 sm:grid-cols-3">
                          <NumberField id={`${scenario.id}-${premise.id}-production`} label="Production here" suffix="units" value={premise.production} onChange={(next) => patch("premises", scenario.premises.map((item) => item.id === premise.id ? { ...item, production: next ?? 0 } : item))} />
                          <NumberField id={`${scenario.id}-${premise.id}-rent`} label="Rent" prefix="Sh" value={premise.rent} tone="estimate" onChange={(next) => patch("premises", scenario.premises.map((item) => item.id === premise.id ? { ...item, rent: next ?? 0 } : item))} />
                          <NumberField id={`${scenario.id}-${premise.id}-transport`} label="Transport / sold unit" prefix="Sh" value={premise.transportRate} step={0.1} tone="estimate" onChange={(next) => patch("premises", scenario.premises.map((item) => item.id === premise.id ? { ...item, transportRate: next ?? 0 } : item))} />
                        </div>
                      ) : null}
                    </div>
                  ))}
                </div>
                <p className="mt-2 text-xs leading-5 text-slate-500">Premises A, B and F were marked as potentially relevant for storage. The official Year 2 storage mechanism is not known and is not modeled.</p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border border-slate-200 p-4">
                  <h4 className="text-sm font-semibold">Owned machines used</h4>
                  <div className="mt-3 space-y-2">
                    {history.machines.map((machine) => (
                      <label key={machine.instanceId} className="flex items-center justify-between gap-3 rounded-lg bg-slate-50 p-3 text-sm">
                        <span className="flex items-center gap-2"><Checkbox checked={scenario.usedOwnedMachineIds.includes(machine.instanceId)} disabled={!machine.available || machine.remainingLife <= 0} onCheckedChange={(checked) => patch("usedOwnedMachineIds", checked ? [...scenario.usedOwnedMachineIds, machine.instanceId] : scenario.usedOwnedMachineIds.filter((id) => id !== machine.instanceId))} />{machine.name}</span>
                        <span className="text-xs text-slate-500">{units(machine.capacity)} capacity</span>
                      </label>
                    ))}
                    {!history.machines.length ? <p className="text-sm text-slate-500">No Year 1 machines entered.</p> : null}
                  </div>
                </div>
                <div className="rounded-xl border border-slate-200 p-4">
                  <h4 className="text-sm font-semibold">Additional machine purchases</h4>
                  <div className="mt-3 space-y-2">
                    {scenario.machinePurchases.map((machine) => (
                      <div key={machine.instanceId} className="flex items-center justify-between gap-2 rounded-lg bg-slate-50 p-3 text-sm">
                        <label className="flex min-w-0 items-center gap-2"><Checkbox checked={machine.used} onCheckedChange={(checked) => patch("machinePurchases", scenario.machinePurchases.map((item) => item.instanceId === machine.instanceId ? { ...item, used: Boolean(checked) } : item))} /><span className="truncate">{machine.name}</span></label>
                        <div className="flex items-center gap-2"><span className="text-xs text-slate-500">{money(machine.purchasePrice)}</span><Button type="button" variant="ghost" size="icon-xs" aria-label={`Remove ${machine.name}`} onClick={() => patch("machinePurchases", scenario.machinePurchases.filter((item) => item.instanceId !== machine.instanceId))}><Trash2 /></Button></div>
                      </div>
                    ))}
                    <div className="flex flex-wrap gap-2 pt-1">
                      <NativeSelect aria-label="Machine purchase reference" value={purchaseReferenceId} onChange={(event) => setPurchaseReferenceId(event.target.value)} className="w-36 bg-white">
                        {MACHINE_REFERENCES.map((machine) => <NativeSelectOption key={machine.id} value={machine.id}>{machine.name}</NativeSelectOption>)}
                      </NativeSelect>
                      <Button type="button" size="sm" variant="outline" onClick={addPurchase}><CirclePlus />Add purchase</Button>
                    </div>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="sales">
            <AccordionTrigger className="text-base"><span className="flex items-center gap-2"><ShoppingCart className="size-4 text-slate-500" />Sales, market &amp; people</span></AccordionTrigger>
            <AccordionContent className="space-y-4">
              <div className="rounded-xl border border-violet-200 bg-violet-50/70 p-4 text-sm text-violet-900"><strong>Market forecast: {units(MARKET_FORECAST)} units.</strong> This is total demand, not guaranteed company sales. Revenue uses trainer allocation only.</div>
              <div className="grid gap-4 sm:grid-cols-2">
                <NumberField id={`${scenario.id}-requested`} label="Requested sales" suffix="units" value={scenario.requestedSales} tone="estimate" onChange={(next) => patch("requestedSales", next ?? 0)} />
                <NumberField id={`${scenario.id}-allocation`} label="Actual trainer allocation" suffix="units" value={scenario.actualAllocation} tone="trainer" onChange={(next) => patch("actualAllocation", next ?? 0)} />
                <NumberField id={`${scenario.id}-price`} label="Selling price" prefix="Sh" value={scenario.sellingPrice} step={0.1} onChange={(next) => patch("sellingPrice", next ?? 0)} />
                <NumberField id={`${scenario.id}-market`} label="Market investment" prefix="Sh" value={scenario.marketInvestment} tone="estimate" onChange={(next) => patch("marketInvestment", next ?? 0)} />
                <NumberField id={`${scenario.id}-salary`} label="Fixed salaries" prefix="Sh" value={scenario.fixedSalaries} onChange={(next) => patch("fixedSalaries", next ?? 0)} />
                <NumberField id={`${scenario.id}-bonus`} label="Employee bonus" suffix="% of positive GP" value={scenario.bonusRate * 100} step={0.1} tone="estimate" onChange={(next) => patch("bonusRate", (next ?? 0) / 100)} />
                <NumberField id={`${scenario.id}-tax-rate`} label="Tax rate" suffix="%" value={scenario.taxRate * 100} step={0.1} tone="estimate" onChange={(next) => patch("taxRate", (next ?? 0) / 100)} />
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="finance">
            <AccordionTrigger className="text-base"><span className="flex items-center gap-2"><Coins className="size-4 text-slate-500" />Borrowing</span></AccordionTrigger>
            <AccordionContent>
              <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-xs leading-5 text-amber-900">ESTIMATE — Year 1 reference, editable. The first principal and interest payments occur in the borrowing season.</div>
              <div className="grid gap-4 sm:grid-cols-3">
                <NumberField id={`${scenario.id}-borrowing`} label="New borrowing" prefix="Sh" value={scenario.borrowingAmount} tone="estimate" onChange={(next) => patch("borrowingAmount", next ?? 0)} />
                <NumberField id={`${scenario.id}-loan-term`} label="Loan term" suffix="seasons" min={1} value={scenario.loanTerm} tone="estimate" onChange={(next) => patch("loanTerm", Math.max(1, next ?? 1))} />
                <NumberField id={`${scenario.id}-interest`} label="Interest rate / season" suffix="%" value={scenario.interestRate * 100} step={0.1} tone="estimate" onChange={(next) => patch("interestRate", (next ?? 0) / 100)} />
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="statements">
            <AccordionTrigger className="text-base"><span className="flex items-center gap-2"><Landmark className="size-4 text-slate-500" />P&amp;L, cash flow &amp; transport</span></AccordionTrigger>
            <AccordionContent className="grid gap-5 xl:grid-cols-2">
              <div className="rounded-xl bg-slate-50 p-4">
                <h4 className="mb-2 font-semibold">Profit &amp; loss</h4>
                <StatementRow label="Revenue" value={result.revenue} />
                <StatementRow label="Milk cost" value={-result.milkCost} />
                <StatementRow label="Maintenance" value={-result.maintenance} />
                <StatementRow label="Depreciation" value={-result.depreciation} />
                <StatementRow label="Gross profit" value={result.grossProfit} strong />
                <StatementRow label="Transport" value={-result.transport} />
                <StatementRow label="Market investment" value={-result.marketInvestment} />
                <StatementRow label="Employee bonus" value={-result.employeeBonus} />
                <StatementRow label="Fixed salaries" value={-result.fixedSalaries} />
                <StatementRow label="Premise rent" value={-result.rent} />
                <StatementRow label="Loan interest" value={-result.loanInterest} />
                <StatementRow label="Profit before tax" value={result.profitBeforeTax} strong />
                <StatementRow label="Tax-loss pool used" value={result.taxLossPoolUsed} unavailable={taxUnavailable} />
                <StatementRow label="Tax" value={-result.tax} unavailable={taxUnavailable} />
                <StatementRow label="Net profit" value={result.netProfit} strong unavailable={taxUnavailable} />
              </div>
              <div className="rounded-xl bg-slate-50 p-4">
                <h4 className="mb-2 font-semibold">Cash flow</h4>
                <StatementRow label="Opening cash" value={result.openingCash} unavailable={history.closingCash === null} />
                <StatementRow label="New borrowing" value={result.newBorrowing} />
                <StatementRow label="Sales receipts" value={result.revenue} />
                <StatementRow label="Machine purchases" value={-result.machinePurchases} />
                <StatementRow label="Milk purchases" value={-result.milkCost} />
                <StatementRow label="Market investment" value={-result.marketInvestment} />
                <StatementRow label="Premise rent" value={-result.rent} />
                <StatementRow label="Maintenance" value={-result.maintenance} />
                <StatementRow label="Transport" value={-result.transport} />
                <StatementRow label="Fixed salaries" value={-result.fixedSalaries} />
                <StatementRow label="Employee bonus" value={-result.employeeBonus} />
                <StatementRow label="Loan principal" value={-result.loanPrincipal} />
                <StatementRow label="Loan interest" value={-result.loanInterest} />
                <StatementRow label="Tax" value={-result.tax} unavailable={taxUnavailable} />
                <StatementRow label="Closing cash" value={result.closingCash} strong unavailable={cashUnavailable} />
              </div>
              <div className="xl:col-span-2 rounded-xl border border-slate-200 p-4">
                <h4 className="font-semibold">Transport allocation</h4>
                <div className="mt-3 overflow-x-auto">
                  <Table className="min-w-[480px]">
                    <TableHeader><TableRow><TableHead>Premise</TableHead><TableHead>Production</TableHead><TableHead>Sold units</TableHead><TableHead>Rate</TableHead><TableHead className="text-right">Cost</TableHead></TableRow></TableHeader>
                    <TableBody>{result.transportAllocation.map((row) => <TableRow key={row.premiseId}><TableCell>{row.premiseId}</TableCell><TableCell>{units(row.production)}</TableCell><TableCell>{units(row.soldUnits)}</TableCell><TableCell>{row.rate}</TableCell><TableCell className="text-right">{money(row.cost)}</TableCell></TableRow>)}</TableBody>
                  </Table>
                  {!result.transportAllocation.length ? <p className="py-3 text-slate-500">Select a premise and assign production to see the allocation.</p> : null}
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <div className="rounded-2xl border border-slate-200 bg-[#f7f9fc] p-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="flex items-center gap-2 text-sm font-semibold"><TrendingDown className="size-4" />Trainer allocation sensitivity</p>
              <p className="mt-1 text-xs text-slate-500">Test a reduction without overwriting the base trainer allocation.</p>
            </div>
            <span className="rounded-full bg-white px-3 py-1 text-sm font-semibold shadow-sm">{sensitivity}% · {units(result.testedAllocation)} units</span>
          </div>
          <Slider aria-label={`${scenario.name} allocation sensitivity`} className="mt-5" value={[sensitivity]} min={0} max={100} step={5} onValueChange={(next) => onSensitivityChange(next[0])} />
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl bg-white p-3 text-sm"><span className="text-slate-500">Break-even allocation</span><strong className="mt-1 block">{taxUnavailable || result.breakEvenSalesAllocation === null ? "Not reached / unavailable" : `${units(result.breakEvenSalesAllocation)} units`}</strong></div>
            <div className="rounded-xl bg-white p-3 text-sm"><span className="text-slate-500">Minimum allocation for non-negative cash</span><strong className="mt-1 block">{result.minimumAllocationForNonNegativeCash === null ? "Not reached / unavailable" : `${units(result.minimumAllocationForNonNegativeCash)} units`}</strong></div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
