import { ClipboardCheck } from "lucide-react";
import type { DecisionRecord as DecisionRecordType } from "../types/model.ts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export function DecisionRecord({ value, onChange }: { value: DecisionRecordType; onChange: (next: DecisionRecordType) => void }) {
  function patch<K extends keyof DecisionRecordType>(key: K, next: DecisionRecordType[K]) {
    onChange({ ...value, [key]: next });
  }
  const fields: Array<{ key: keyof DecisionRecordType; label: string; long?: boolean }> = [
    { key: "selectedStrategy", label: "Selected strategy" },
    { key: "mainAssumption", label: "Main assumption" },
    { key: "expectedTrainerAllocation", label: "Expected trainer allocation" },
    { key: "mainRisk", label: "Main risk", long: true },
    { key: "lowerAllocationOutcome", label: "What happens if allocation is lower", long: true },
    { key: "reason", label: "Reason for choosing this strategy", long: true },
  ];
  return (
    <Card className="border-slate-200">
      <CardHeader><p className="text-xs font-bold uppercase tracking-[0.16em] text-slate-500">Student judgment</p><CardTitle className="flex items-center gap-2 text-2xl"><ClipboardCheck className="size-5 text-slate-500" />Year 2 Winter Decision</CardTitle><p className="text-sm text-slate-500">The model informs this record but does not choose a strategy for you.</p></CardHeader>
      <CardContent className="grid gap-4 md:grid-cols-2">
        {fields.map((field) => <div key={field.key} className={field.key === "reason" ? "md:col-span-2" : ""}><Label htmlFor={`decision-${field.key}`} className="mb-2">{field.label}</Label>{field.long ? <Textarea id={`decision-${field.key}`} value={value[field.key]} onChange={(event) => patch(field.key, event.target.value)} className="min-h-24 bg-white" /> : <Input id={`decision-${field.key}`} value={value[field.key]} onChange={(event) => patch(field.key, event.target.value)} className="h-10 bg-white" />}</div>)}
      </CardContent>
    </Card>
  );
}
