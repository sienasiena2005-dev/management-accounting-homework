import { ArrowRightLeft } from "lucide-react";
import { calculateTradeoff } from "../lib/calculations.ts";
import type { HistoricalPosition, ScenarioInput, ScenarioResult } from "../types/model.ts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const money = (value: number) => `Sh ${value.toLocaleString()}`;
const number = (value: number) => value.toLocaleString();

export function ComparisonDashboard({ scenarios, results, history }: { scenarios: [ScenarioInput, ScenarioInput]; results: [ScenarioResult, ScenarioResult]; history: HistoricalPosition }) {
  const [a, b] = results;
  const taxUnavailable = history.taxLossCarryforward === null;
  const cashUnavailable = history.closingCash === null || taxUnavailable;
  const rows: Array<{ label: string; key: keyof ScenarioResult; format: "money" | "number"; unavailable?: boolean }> = [
    { label: "Net profit", key: "netProfit", format: "money", unavailable: taxUnavailable },
    { label: "Closing cash", key: "closingCash", format: "money", unavailable: cashUnavailable },
    { label: "Revenue", key: "revenue", format: "money" },
    { label: "Units sold", key: "unitsSold", format: "number" },
    { label: "Unsold ice cream", key: "unsoldIceCream", format: "number" },
    { label: "Unused milk (equivalent units)", key: "unusedMilk", format: "number" },
    { label: "Spoilage exposure", key: "spoilageExposure", format: "number" },
    { label: "Rent", key: "rent", format: "money" },
    { label: "Transport", key: "transport", format: "money" },
    { label: "Maintenance", key: "maintenance", format: "money" },
    { label: "Depreciation", key: "depreciation", format: "money" },
    { label: "Market spending", key: "marketInvestment", format: "money" },
    { label: "Interest", key: "loanInterest", format: "money" },
    { label: "Tax", key: "tax", format: "money", unavailable: taxUnavailable },
    { label: "Debt remaining", key: "endingDebt", format: "money", unavailable: !history.loansConfirmed },
    { label: "Cash before advance payments", key: "cashBeforeAdvancePayments", format: "money", unavailable: history.closingCash === null },
  ];

  function display(value: number, format: "money" | "number", unavailable?: boolean) {
    if (unavailable) return "—";
    return format === "money" ? money(value) : number(value);
  }

  return (
    <Card className="border-slate-200 shadow-[0_14px_40px_rgba(15,23,42,0.05)]">
      <CardHeader>
        <p className="text-xs font-bold uppercase tracking-[0.16em] text-slate-500">Direct comparison</p>
        <CardTitle className="flex items-center gap-2 text-2xl"><ArrowRightLeft className="size-5 text-slate-500" />Strategy comparison</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <Table className="min-w-[720px]">
            <TableHeader><TableRow className="bg-slate-50"><TableHead>Metric</TableHead><TableHead>{scenarios[0].name}</TableHead><TableHead>{scenarios[1].name}</TableHead><TableHead className="text-right">B − A</TableHead></TableRow></TableHeader>
            <TableBody>
              {rows.map((row) => {
                const av = a[row.key] as number;
                const bv = b[row.key] as number;
                const delta = bv - av;
                return (
                  <TableRow key={row.label}>
                    <TableCell className="font-medium">{row.label}</TableCell>
                    <TableCell>{display(av, row.format, row.unavailable)}</TableCell>
                    <TableCell>{display(bv, row.format, row.unavailable)}</TableCell>
                    <TableCell className={`text-right font-semibold ${row.unavailable ? "text-slate-400" : delta > 0 ? "text-emerald-700" : delta < 0 ? "text-red-700" : "text-slate-500"}`}>{display(delta, row.format, row.unavailable)}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        <div className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
          <p className="text-xs font-bold uppercase tracking-[0.15em] text-blue-700">Calculated trade-off</p>
          <p className="mt-2 max-w-5xl text-sm leading-6 text-blue-950">{calculateTradeoff(a, b, scenarios[0].name, scenarios[1].name)}</p>
          <p className="mt-2 text-xs text-blue-700">This is a comparison, not an automatic recommendation.</p>
        </div>
      </CardContent>
    </Card>
  );
}
