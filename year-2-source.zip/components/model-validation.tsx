import { BadgeCheck, CircleX } from "lucide-react";
import type { AppState, ScenarioInput, ScenarioResult } from "../types/model.ts";
import { NumberField } from "./number-field";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";

export function ModelValidation({ state, scenarios, results, onChange }: { state: AppState["validation"]; scenarios: [ScenarioInput, ScenarioInput]; results: [ScenarioResult, ScenarioResult]; onChange: (next: AppState["validation"]) => void }) {
  const index = state.scenarioId === "a" ? 0 : 1;
  const result = results[index];
  const netDifference = state.expectedNetProfit === null ? null : Math.round(result.netProfit) - Math.round(state.expectedNetProfit);
  const cashDifference = state.expectedClosingCash === null ? null : Math.round(result.closingCash) - Math.round(state.expectedClosingCash);
  const pass = netDifference === 0 && cashDifference === 0;
  const complete = netDifference !== null && cashDifference !== null && !result.missingHistory.length;
  return (
    <Card className="border-slate-200 shadow-none">
      <CardContent className="pt-0">
        <Accordion type="single" collapsible>
          <AccordionItem value="validation">
            <AccordionTrigger className="py-5 text-base">Model Validation</AccordionTrigger>
            <AccordionContent className="space-y-5">
              <p className="max-w-4xl text-sm leading-6 text-slate-600">Configure one scenario with a real Year 1 season, select it here, then enter the expected reported results. PASS requires both values to match after whole-shekel rounding.</p>
              <div className="grid gap-4 md:grid-cols-3">
                <div><p className="mb-2 text-sm font-medium text-slate-700">Calculated scenario</p><NativeSelect className="h-10 w-full bg-white" value={state.scenarioId} onChange={(event) => onChange({ ...state, scenarioId: event.target.value as "a" | "b" })}><NativeSelectOption value="a">{scenarios[0].name}</NativeSelectOption><NativeSelectOption value="b">{scenarios[1].name}</NativeSelectOption></NativeSelect></div>
                <NumberField id="expected-net-profit" label="Expected net profit" prefix="Sh" value={state.expectedNetProfit} nullable onChange={(value) => onChange({ ...state, expectedNetProfit: value })} />
                <NumberField id="expected-closing-cash" label="Expected closing cash" prefix="Sh" value={state.expectedClosingCash} nullable onChange={(value) => onChange({ ...state, expectedClosingCash: value })} />
              </div>
              <div className={`rounded-xl border p-4 ${complete && pass ? "border-emerald-200 bg-emerald-50" : complete ? "border-red-200 bg-red-50" : "border-slate-200 bg-slate-50"}`}>
                <p className="flex items-center gap-2 font-semibold">{complete && pass ? <><BadgeCheck className="size-5 text-emerald-700" />PASS</> : complete ? <><CircleX className="size-5 text-red-700" />FAIL</> : "Enter both expected values and complete Year 1 inputs"}</p>
                <div className="mt-3 grid gap-3 text-sm sm:grid-cols-2"><p>Calculated net profit: <strong>Sh {result.netProfit.toLocaleString()}</strong>{netDifference !== null ? ` · Difference ${netDifference.toLocaleString()}` : ""}</p><p>Calculated closing cash: <strong>Sh {result.closingCash.toLocaleString()}</strong>{cashDifference !== null ? ` · Difference ${cashDifference.toLocaleString()}` : ""}</p></div>
              </div>
              <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900"><strong>Automated worked-example check:</strong> the test suite verifies gross profit Sh 35,200, net profit −Sh 3,560 and closing cash Sh 71,940 using the official Year 1 example.</div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}
