"use client";

import { useState } from "react";
import { CirclePlus, Landmark, Trash2, Wrench } from "lucide-react";
import { MACHINE_LIFE_SEASONS, MACHINE_REFERENCES } from "../data/year1Reference.ts";
import type { HistoricalPosition } from "../types/model.ts";
import { NumberField } from "./number-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { Switch } from "@/components/ui/switch";

function newId(prefix: string) {
  return `${prefix}-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`;
}

export function Year1Position({ value, onChange }: { value: HistoricalPosition; onChange: (next: HistoricalPosition) => void }) {
  const [machineReferenceId, setMachineReferenceId] = useState(MACHINE_REFERENCES[0].id);
  const debt = value.loans.reduce((sum, loan) => sum + loan.outstandingPrincipal, 0);

  function patch<K extends keyof HistoricalPosition>(key: K, next: HistoricalPosition[K]) {
    onChange({ ...value, [key]: next });
  }

  function addMachine() {
    const reference = MACHINE_REFERENCES.find((machine) => machine.id === machineReferenceId)!;
    patch("machines", [...value.machines, { ...reference, instanceId: newId("owned"), remainingLife: MACHINE_LIFE_SEASONS, available: true }]);
  }

  function addLoan() {
    patch("loans", [...value.loans, {
      id: newId("loan"), label: `Loan ${value.loans.length + 1}`, outstandingPrincipal: 0,
      remainingTerm: 1, interestRate: 0.1, scheduledPrincipalPayment: 0,
    }]);
  }

  return (
    <Card className="border-blue-200 bg-blue-50/55 shadow-none">
      <CardHeader className="gap-3 pb-2">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.17em] text-blue-700">Historical Year 1 data</p>
            <CardTitle className="mt-2 flex items-center gap-2 text-2xl tracking-tight"><Landmark className="size-5 text-blue-700" />Year 1 Closing Position</CardTitle>
          </div>
          <div className="rounded-xl border border-blue-200 bg-white px-4 py-3 text-right">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Outstanding debt</p>
            <p className="mt-1 text-lg font-semibold">{value.loansConfirmed ? `Sh ${debt.toLocaleString()}` : "Not confirmed"}</p>
          </div>
        </div>
        <p className="max-w-4xl text-sm leading-6 text-slate-600">The actual company results were not supplied. Enter them here and confirm whether the company has no loans or machines. These fields feed both Year 2 strategies.</p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-4 md:grid-cols-3">
          <NumberField id="y1-closing-cash" label="Closing cash after Autumn" prefix="Sh" value={value.closingCash} nullable tone="historical" onChange={(next) => patch("closingCash", next)} />
          <NumberField id="y1-profit" label="Year 1 annual net profit" prefix="Sh" value={value.annualNetProfit} nullable tone="historical" onChange={(next) => patch("annualNetProfit", next)} />
          <NumberField id="y1-tax-loss" label="Unused tax-loss carryforward" prefix="Sh" value={value.taxLossCarryforward} nullable tone="historical" onChange={(next) => patch("taxLossCarryforward", next)} />
        </div>

        <div className="grid gap-5 xl:grid-cols-2">
          <section className="rounded-2xl border border-blue-200 bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-semibold text-slate-950">Outstanding Year 1 loans</h3>
                <p className="mt-1 text-xs text-slate-500">Enter every balance still payable in Year 2.</p>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="loans-confirmed" className="text-xs">List is complete</Label>
                <Switch id="loans-confirmed" checked={value.loansConfirmed} onCheckedChange={(checked) => patch("loansConfirmed", checked)} />
              </div>
            </div>
            <div className="mt-4 space-y-3">
              {value.loans.map((loan, index) => (
                <div key={loan.id} className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <Input aria-label={`Loan ${index + 1} name`} value={loan.label} onChange={(event) => patch("loans", value.loans.map((item) => item.id === loan.id ? { ...item, label: event.target.value } : item))} className="h-8 bg-white font-semibold" />
                    <Button type="button" variant="ghost" size="icon-sm" aria-label={`Remove ${loan.label}`} onClick={() => patch("loans", value.loans.filter((item) => item.id !== loan.id))}><Trash2 /></Button>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <NumberField id={`${loan.id}-principal`} label="Outstanding principal" prefix="Sh" value={loan.outstandingPrincipal} onChange={(next) => patch("loans", value.loans.map((item) => item.id === loan.id ? { ...item, outstandingPrincipal: next ?? 0 } : item))} />
                    <NumberField id={`${loan.id}-term`} label="Remaining term" suffix="seasons" value={loan.remainingTerm} min={1} onChange={(next) => patch("loans", value.loans.map((item) => item.id === loan.id ? { ...item, remainingTerm: next ?? 1 } : item))} />
                    <NumberField id={`${loan.id}-rate`} label="Interest rate" suffix="%" value={loan.interestRate * 100} step={0.1} onChange={(next) => patch("loans", value.loans.map((item) => item.id === loan.id ? { ...item, interestRate: (next ?? 0) / 100 } : item))} />
                    <NumberField id={`${loan.id}-payment`} label="Scheduled principal / season" prefix="Sh" value={loan.scheduledPrincipalPayment} hint="Leave at 0 to divide the balance across the remaining term." onChange={(next) => patch("loans", value.loans.map((item) => item.id === loan.id ? { ...item, scheduledPrincipalPayment: next ?? 0 } : item))} />
                  </div>
                </div>
              ))}
              {!value.loans.length ? <p className="rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">No loans entered. Turn on “List is complete” to confirm the company has none.</p> : null}
              <Button type="button" variant="outline" onClick={addLoan}><CirclePlus />Add existing loan</Button>
            </div>
          </section>

          <section className="rounded-2xl border border-blue-200 bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-semibold text-slate-950">Owned machines</h3>
                <p className="mt-1 text-xs text-slate-500">All fields remain editable if the historical record differs.</p>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="machines-confirmed" className="text-xs">List is complete</Label>
                <Switch id="machines-confirmed" checked={value.machinesConfirmed} onCheckedChange={(checked) => patch("machinesConfirmed", checked)} />
              </div>
            </div>
            <div className="mt-4 space-y-3">
              {value.machines.map((machine, index) => (
                <div key={machine.instanceId} className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <Wrench className="size-4 text-blue-700" />
                    <Input aria-label={`Owned machine ${index + 1} identifier`} value={machine.name} onChange={(event) => patch("machines", value.machines.map((item) => item.instanceId === machine.instanceId ? { ...item, name: event.target.value } : item))} className="h-8 bg-white font-semibold" />
                    <Button type="button" variant="ghost" size="icon-sm" aria-label={`Remove ${machine.name}`} onClick={() => patch("machines", value.machines.filter((item) => item.instanceId !== machine.instanceId))}><Trash2 /></Button>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-3">
                    {([
                      ["capacity", "Capacity", "units"], ["purchasePrice", "Purchase price", "Sh"], ["maintenance", "Maintenance / season", "Sh"],
                      ["depreciation", "Depreciation / season", "Sh"], ["remainingLife", "Remaining useful life", "seasons"],
                    ] as const).map(([field, label, suffix]) => (
                      <NumberField key={field} id={`${machine.instanceId}-${field}`} label={label} value={machine[field]} prefix={suffix === "Sh" ? "Sh" : undefined} suffix={suffix !== "Sh" ? suffix : undefined} onChange={(next) => patch("machines", value.machines.map((item) => item.instanceId === machine.instanceId ? { ...item, [field]: next ?? 0 } : item))} />
                    ))}
                    <div className="flex items-end gap-2 pb-2">
                      <Switch id={`${machine.instanceId}-available`} checked={machine.available} onCheckedChange={(checked) => patch("machines", value.machines.map((item) => item.instanceId === machine.instanceId ? { ...item, available: checked } : item))} />
                      <Label htmlFor={`${machine.instanceId}-available`}>Available for use</Label>
                    </div>
                  </div>
                </div>
              ))}
              {!value.machines.length ? <p className="rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">No machines entered. Turn on “List is complete” to confirm the company owns none.</p> : null}
              <div className="flex flex-wrap gap-2">
                <NativeSelect aria-label="Machine reference to add" value={machineReferenceId} onChange={(event) => setMachineReferenceId(event.target.value)} className="w-44 bg-white">
                  {MACHINE_REFERENCES.map((machine) => <NativeSelectOption key={machine.id} value={machine.id}>{machine.name}</NativeSelectOption>)}
                </NativeSelect>
                <Button type="button" variant="outline" onClick={addMachine}><CirclePlus />Add owned machine</Button>
              </div>
            </div>
          </section>
        </div>
      </CardContent>
    </Card>
  );
}
