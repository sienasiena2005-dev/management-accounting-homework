import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type NumberFieldProps = {
  id: string;
  label: string;
  value: number | null;
  onChange: (value: number | null) => void;
  prefix?: string;
  suffix?: string;
  nullable?: boolean;
  step?: number;
  min?: number;
  tone?: "standard" | "historical" | "trainer" | "estimate";
  hint?: string;
};

export function NumberField({
  id,
  label,
  value,
  onChange,
  prefix,
  suffix,
  nullable = false,
  step = 1,
  min = 0,
  tone = "standard",
  hint,
}: NumberFieldProps) {
  const toneClass = {
    standard: "bg-white",
    historical: "border-blue-200 bg-blue-50/70",
    trainer: "border-violet-300 bg-violet-50 ring-1 ring-violet-100",
    estimate: "border-amber-200 bg-amber-50/70",
  }[tone];
  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="text-sm text-slate-700">{label}</Label>
      <div className="relative">
        {prefix ? <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-slate-400">{prefix}</span> : null}
        <Input
          id={id}
          type="number"
          inputMode="decimal"
          min={min}
          step={step}
          value={value ?? ""}
          onChange={(event) => {
            if (event.target.value === "") onChange(nullable ? null : 0);
            else onChange(Number(event.target.value));
          }}
          className={`h-10 ${prefix ? "pl-10" : ""} ${suffix ? "pr-14" : ""} ${toneClass}`}
          placeholder={nullable ? "Not provided" : "0"}
        />
        {suffix ? <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400">{suffix}</span> : null}
      </div>
      {hint ? <p className="text-xs leading-5 text-slate-500">{hint}</p> : null}
    </div>
  );
}
