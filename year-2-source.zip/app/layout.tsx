import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Year 2 Winter Decision Tool",
  description: "Editable financial planning and strategy comparison for Pork & Garlic Ice Cream Co.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
