"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Download, RotateCcw, Snowflake, Upload } from "lucide-react";
import { ComparisonDashboard } from "../components/comparison-dashboard";
import { DecisionRecord } from "../components/decision-record";
import { ModelValidation } from "../components/model-validation";
import { ReferenceRules } from "../components/reference-rules";
import { ScenarioPanel } from "../components/scenario-panel";
import { Year1Position } from "../components/year1-position";
import { calculateScenario } from "../lib/calculations.ts";
import { createDefaultState } from "../lib/defaults.ts";
import type { AppState, HistoricalPosition, ScenarioResult } from "../types/model.ts";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";

const STORAGE_KEY = "pork-garlic-year2-winter-student-v1";

function currentStorageKey() {
  const qaKey = new URLSearchParams(window.location.search).get("qa");
  return qaKey ? `${STORAGE_KEY}-qa-${qaKey}` : STORAGE_KEY;
}

function isAppState(value: unknown): value is AppState {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<AppState>;
  return candidate.version === 1 && Array.isArray(candidate.scenarios) && candidate.scenarios.length === 2 && Boolean(candidate.year1);
}

export default function Home() {
  const [state, setState] = useState<AppState>(() => createDefaultState());
  const [hydrated, setHydrated] = useState(false);
  const [importError, setImportError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const stateRef = useRef(state);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        const saved = localStorage.getItem(currentStorageKey());
        if (saved) {
          const parsed: unknown = JSON.parse(saved);
          if (isAppState(parsed)) setState(parsed);
        }
      } catch {
        setImportError("Saved browser data could not be read. A blank starting position is shown.");
      } finally {
        setHydrated(true);
      }
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(currentStorageKey(), JSON.stringify(state));
  }, [hydrated, state]);

  const results = useMemo<[ScenarioResult, ScenarioResult]>(() => [
    calculateScenario(state.scenarios[0], state.year1, state.sensitivity[0]),
    calculateScenario(state.scenarios[1], state.year1, state.sensitivity[1]),
  ], [state]);

  useEffect(() => {
    const context = document.modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const register = async () => {
      await context.registerTool({
        name: "read_winter_model_summary",
        title: "Read Winter model summary",
        description: "Read the current Year 1 input completeness and both Year 2 scenario headline results without changing the model.",
        inputSchema: { type: "object", properties: {}, additionalProperties: false },
        annotations: { readOnlyHint: true, untrustedContentHint: false },
        execute: () => {
          const current = stateRef.current;
          return {
            year1_complete: current.year1.closingCash !== null && current.year1.taxLossCarryforward !== null && current.year1.loansConfirmed && current.year1.machinesConfirmed,
            scenarios: current.scenarios.map((scenario, index) => {
              const result = calculateScenario(scenario, current.year1, current.sensitivity[index]);
              return { name: scenario.name, revenue: result.revenue, net_profit: result.netProfit, closing_cash: result.closingCash, warnings: result.warnings };
            }),
          };
        },
      }, { signal: lifecycle.signal });
      await context.registerTool({
        name: "set_year1_closing_position",
        title: "Set Year 1 closing position",
        description: "Set the three editable Year 1 headline values used by both Year 2 scenarios.",
        inputSchema: {
          type: "object",
          properties: {
            closingCash: { type: "number" }, annualNetProfit: { type: "number" }, taxLossCarryforward: { type: "number", minimum: 0 },
          },
          required: ["closingCash", "annualNetProfit", "taxLossCarryforward"],
          additionalProperties: false,
        },
        annotations: { readOnlyHint: false, untrustedContentHint: false },
        execute: (input) => {
          const values = input as Pick<HistoricalPosition, "closingCash" | "annualNetProfit" | "taxLossCarryforward">;
          if (![values.closingCash, values.annualNetProfit, values.taxLossCarryforward].every((value) => typeof value === "number" && Number.isFinite(value))) throw new Error("All Year 1 values must be finite numbers.");
          if ((values.taxLossCarryforward ?? 0) < 0) throw new Error("Tax-loss carryforward cannot be negative.");
          setState((current) => ({ ...current, year1: { ...current.year1, ...values } }));
          return { updated: true, ...values };
        },
      }, { signal: lifecycle.signal });
    };
    void register().catch(() => undefined);
    return () => lifecycle.abort();
  }, []);

  function updateScenario(index: 0 | 1, next: AppState["scenarios"][number]) {
    setState((current) => ({ ...current, scenarios: index === 0 ? [next, current.scenarios[1]] : [current.scenarios[0], next] }));
  }

  function updateSensitivity(index: 0 | 1, next: number) {
    setState((current) => ({ ...current, sensitivity: index === 0 ? [next, current.sensitivity[1]] : [current.sensitivity[0], next] }));
  }

  function exportState() {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "year-2-winter-scenarios.json";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  async function importState(file: File | undefined) {
    if (!file) return;
    try {
      const parsed: unknown = JSON.parse(await file.text());
      if (!isAppState(parsed)) throw new Error("Invalid file");
      setState(parsed);
      setImportError("");
    } catch {
      setImportError("That file is not a valid Year 2 Winter scenario export.");
    }
  }

  return (
    <main className="min-h-screen bg-[#f4f7fb] text-slate-950">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#0b1730]/95 text-white shadow-lg shadow-slate-950/10 backdrop-blur">
        <div className="mx-auto flex max-w-[1560px] flex-wrap items-center justify-between gap-4 px-4 py-4 sm:px-8">
          <div className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-xl bg-white/10"><Snowflake className="size-5" /></span>
            <div><p className="text-sm font-semibold">Pork &amp; Garlic Ice Cream Co.</p><p className="text-xs text-slate-300">Year 2 Winter Decision Tool</p></div>
          </div>
          <div className="flex flex-wrap items-center justify-end gap-2">
            <span className="mr-1 hidden items-center gap-2 text-xs text-slate-300 sm:flex"><span className={`size-2 rounded-full ${hydrated ? "bg-emerald-400" : "bg-amber-400"}`} />{hydrated ? "Saved locally" : "Loading"}</span>
            <input ref={fileInputRef} type="file" accept="application/json" className="hidden" onChange={(event) => { void importState(event.target.files?.[0]); event.currentTarget.value = ""; }} />
            <Button type="button" size="sm" variant="secondary" onClick={() => fileInputRef.current?.click()}><Upload />Import</Button>
            <Button type="button" size="sm" variant="secondary" onClick={exportState}><Download />Export</Button>
            <AlertDialog>
              <AlertDialogTrigger asChild><Button type="button" size="sm" variant="outline" className="border-white/25 bg-transparent text-white hover:bg-white/10 hover:text-white"><RotateCcw />Reset</Button></AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader><AlertDialogTitle>Reset the planning model?</AlertDialogTitle><AlertDialogDescription>This clears the Year 1 position, both scenarios and the decision record stored for this project in this browser.</AlertDialogDescription></AlertDialogHeader>
                <AlertDialogFooter><AlertDialogCancel>Keep model</AlertDialogCancel><AlertDialogAction variant="destructive" onClick={() => setState(createDefaultState())}>Reset to starting position</AlertDialogAction></AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-[1560px] space-y-7 px-4 py-7 sm:px-8 sm:py-10">
        <section className="grid gap-6 xl:grid-cols-[0.58fr_1.42fr]">
          <div className="flex min-h-[320px] flex-col justify-between rounded-2xl bg-[#13233f] p-6 text-white shadow-[0_18px_50px_rgba(15,23,42,0.16)] sm:p-8">
            <div><p className="text-xs font-bold uppercase tracking-[0.18em] text-blue-200">Planning workspace</p><h1 className="mt-4 text-3xl font-semibold leading-tight tracking-tight sm:text-4xl">Compare the profit, cash and downside exposure of two Winter strategies.</h1></div>
            <div className="mt-8 space-y-3"><p className="text-sm leading-6 text-slate-300">Year 1 company results were not provided. Historical fields therefore start blank and remain editable. No company-specific figures have been inserted.</p><div className="flex items-center gap-2 text-xs font-semibold text-amber-200"><span className="size-2 rounded-full bg-amber-400" />Official Year 2 rules are still pending</div></div>
          </div>
          <Year1Position value={state.year1} onChange={(year1) => setState((current) => ({ ...current, year1 }))} />
        </section>

        {importError ? <div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">{importError}</div> : null}
        <ReferenceRules />

        <section>
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-slate-500">Year 2 Winter scenarios</p><h2 className="mt-2 text-2xl font-semibold tracking-tight">Strategy workspace</h2></div><p className="text-sm text-slate-500">Changes recalculate immediately and save in this browser.</p></div>
          <div className="grid items-start gap-5 2xl:grid-cols-2">
            <ScenarioPanel scenario={state.scenarios[0]} history={state.year1} result={results[0]} sensitivity={state.sensitivity[0]} onChange={(next) => updateScenario(0, next)} onSensitivityChange={(next) => updateSensitivity(0, next)} />
            <ScenarioPanel scenario={state.scenarios[1]} history={state.year1} result={results[1]} sensitivity={state.sensitivity[1]} onChange={(next) => updateScenario(1, next)} onSensitivityChange={(next) => updateSensitivity(1, next)} />
          </div>
        </section>

        <ComparisonDashboard scenarios={state.scenarios} results={results} history={state.year1} />
        <DecisionRecord value={state.decision} onChange={(decision) => setState((current) => ({ ...current, decision }))} />
        <ModelValidation state={state.validation} scenarios={state.scenarios} results={results} onChange={(validation) => setState((current) => ({ ...current, validation }))} />

        <footer className="border-t border-slate-200 py-5 text-xs leading-5 text-slate-500">Whole-shekel classroom rounding is applied to each line before subtotals. Machine purchases and loan principal affect cash only. Depreciation and loan interest affect profit under the rules shown above.</footer>
      </div>
    </main>
  );
}
