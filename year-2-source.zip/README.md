# Pork & Garlic Ice Cream Co. — Year 2 Winter Decision Tool

A browser-based financial planning model for comparing two Year 2 Winter strategies. The application separates accounting profit from cash flow, models trainer-determined sales allocation, tracks debt and tax losses, and highlights capacity and liquidity problems.

## Important data status

The student's actual Year 1 results were not supplied when this project was created. The Year 1 Closing Position therefore starts blank and is fully editable. No company-specific cash, profit, debt, machine ownership or tax-loss values have been invented.

The rules shown for premises, machines, bonus, tax, borrowing and timing are Year 1 references. They are visibly labelled **ESTIMATE — Year 1 reference, editable** because official Year 2 rules have not yet been issued.

## Technology

- Next.js-style React application built with TypeScript
- Vinext/Vite production build for Sites and static export compatibility
- Tailwind CSS with accessible Shadcn/Radix controls
- Browser `localStorage`; no database and no authentication
- Node's built-in test runner for the financial model

## Project structure

- `app/` — page, metadata and global visual theme
- `components/` — Year 1 inputs, scenario panels, comparison, decision record and validation
- `data/` — official Year 1 premise/machine references and the intentionally blank student starting position
- `lib/` — calculations, cash treatment, loans, tax, transport allocation, validation, defaults and rounding
- `types/` — model types and optional WebMCP browser types
- `tests/` — worked-example and accounting-boundary tests

Important formulas do not live in UI components.

## Install and run locally

```bash
npm ci
npm run dev
```

Open the local URL printed by the development server.

## Quality checks

```bash
npm test
npm run typecheck
npm run lint
npm run build
```

The mandatory automated test uses the official Year 1 worked example and requires these whole-shekel outputs:

- Gross profit: Sh 35,200
- Employee bonus: Sh 1,760
- Profit before tax: −Sh 3,560
- Tax: Sh 0
- Net profit: −Sh 3,560
- Closing cash: Sh 71,940
- Tax-loss pool increase: Sh 3,560

Additional tests cover capital purchases versus depreciation, loan principal versus interest, tax-loss use, transport rounding and lower sales allocation.

## Calculation approach

Each financial line is posted to the nearest whole shekel before subtotals are built.

### Profit and loss

Revenue uses **actual trainer allocation × selling price**, never requested sales. Milk, maintenance and depreciation produce gross profit. Transport, market spending, bonus, salaries, rent and interest produce profit before tax. Existing tax losses offset positive profit before tax, while losses increase the carryforward pool.

Machine purchases and loan principal never enter profit. Depreciation and loan interest do.

### Cash flow

Cash flow starts from Year 1 closing cash, adds new borrowing and sales receipts, then deducts machine purchases and all cash operating costs, loan principal, interest and tax. Depreciation never enters cash flow.

`Cash Before Advance Payments` follows the current Year 1 timing reference: opening cash plus new borrowing, less machine purchases, milk and market investment.

### Capacity, transport and inventory

- Production is checked against milk yield and active machine capacity.
- Machines used are checked against selected premise slots.
- Actual sales are checked against production and requested sales.
- Unused milk and unsold finished ice cream are shown separately.
- Actual sales are allocated across premises in proportion to production using whole units; the final premise receives any rounding residual.
- Spoilage exposure is an operational quantity only. It does not add a second expense because milk purchases are already expensed.

### Loans

Existing loans and new borrowing are tracked separately. Under the editable Year 1 reference, interest is charged on principal outstanding immediately before repayment, and the first interest and principal payments occur in the borrowing season.

## Year 1 versus Year 2

Blue sections contain historical Year 1 company inputs. Amber fields contain provisional Year 1 rules reused as editable Year 2 estimates. Violet highlights mark trainer-determined allocation. Red indicates invalid or financially impossible plans; green indicates valid calculations.

The 410,000-unit Winter figure is total market demand and is not a sales guarantee.

Premises A, B and F were flagged as potentially relevant for Year 2 storage. The application states this fact but does not invent a storage mechanism.

## Saved data, reset, import and export

The complete Year 1 position, both scenarios, sensitivity settings and decision record are stored under a project-specific browser key. Refreshing the page keeps the data on that device.

- **Reset** clears only this project's browser data and restores blank Year 1 fields.
- **Export** downloads the current model as JSON.
- **Import** accepts a JSON file exported by this application.

## GitHub workflow

Create a dedicated repository, such as `year-2-decision-simulator`, and verify the remote belongs to the current student's GitHub account before pushing:

```bash
git init
git add .
git commit -m "Build Year 2 Winter decision tool"
git branch -M main
git remote add origin <student-repository-url>
git push -u origin main
```

Do not reuse another student's repository or deployment.

## Vercel deployment

1. Push this project to the student's dedicated GitHub repository.
2. In Vercel, choose **Add New Project** and import that repository.
3. Keep the detected Next.js settings.
4. Deploy and test localStorage, mobile layout, scenario independence and JSON export/import in the production URL.

No environment variables, database or authentication setup is required.

## Manual verification before submission

- Replace every blank Year 1 value with the student's actual records and confirm the loan and machine lists are complete.
- Recheck every amber Year 1 reference against the official Year 2 rules when released.
- Configure one scenario to match a real Year 1 season and use Model Validation to compare expected versus calculated net profit and closing cash.
- Test both strategies at lower trainer allocations and review advance cash, closing cash and unsold inventory.
- Confirm the final written decision record reflects the student's own judgment.
