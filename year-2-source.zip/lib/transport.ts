import type { PremisePlan, TransportAllocation } from "../types/model.ts";
import { post } from "./rounding.ts";

export function allocateTransport(premises: PremisePlan[], actualSales: number): TransportAllocation[] {
  const active = premises.filter((premise) => premise.selected && premise.production > 0);
  const totalProduction = active.reduce((sum, premise) => sum + premise.production, 0);
  if (!active.length || totalProduction <= 0 || actualSales <= 0) {
    return active.map((premise) => ({ premiseId: premise.id, production: post(premise.production), soldUnits: 0, rate: premise.transportRate, cost: 0 }));
  }

  let allocated = 0;
  return active.map((premise, index) => {
    const soldUnits = index === active.length - 1
      ? post(actualSales - allocated)
      : post((actualSales * premise.production) / totalProduction);
    allocated += soldUnits;
    return {
      premiseId: premise.id,
      production: post(premise.production),
      soldUnits,
      rate: premise.transportRate,
      cost: post(soldUnits * premise.transportRate),
    };
  });
}
