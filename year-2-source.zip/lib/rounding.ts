export function post(value: number): number {
  return Math.round(Number.isFinite(value) ? value : 0);
}

export function nonNegative(value: number): number {
  return Math.max(0, Number.isFinite(value) ? value : 0);
}
