import { PREMISE_REFERENCES, YEAR1_REFERENCE } from "../data/year1Reference.ts";
import { EMPTY_STUDENT_STARTING_POSITION } from "../data/studentStartingPosition.ts";
import type { AppState, ScenarioInput } from "../types/model.ts";

function scenario(id: "a" | "b", name: string): ScenarioInput {
  return {
    id,
    name,
    plannedProduction: 0,
    milkTons: 0,
    milkCostPerTon: 20_000,
    milkYieldPerTon: 20_000,
    requestedSales: 0,
    actualAllocation: 0,
    sellingPrice: 2,
    marketInvestment: YEAR1_REFERENCE.minimumMarketInvestment,
    premises: PREMISE_REFERENCES.map((premise) => ({ ...premise, selected: false, production: 0 })),
    usedOwnedMachineIds: [],
    machinePurchases: [],
    borrowingAmount: 0,
    loanTerm: 1,
    interestRate: YEAR1_REFERENCE.loanInterestRate,
    fixedSalaries: 10_000,
    bonusRate: YEAR1_REFERENCE.bonusRate,
    taxRate: YEAR1_REFERENCE.taxRate,
  };
}

export function createDefaultState(): AppState {
  return {
    version: 1,
    year1: structuredClone(EMPTY_STUDENT_STARTING_POSITION),
    scenarios: [scenario("a", "Option A — Conservative"), scenario("b", "Option B — Growth")],
    sensitivity: [100, 100],
    decision: {
      selectedStrategy: "",
      mainAssumption: "",
      expectedTrainerAllocation: "",
      mainRisk: "",
      lowerAllocationOutcome: "",
      reason: "",
    },
    validation: { scenarioId: "a", expectedNetProfit: null, expectedClosingCash: null },
  };
}
