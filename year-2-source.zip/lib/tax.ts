import type { TaxResult } from "../types/model.ts";
import { post } from "./rounding.ts";

export function calculateTax(profitBeforeTax: number, openingLossPool: number, taxRate: number): TaxResult {
  const pbt = post(profitBeforeTax);
  const opening = post(Math.max(0, openingLossPool));
  if (pbt <= 0) {
    return { lossPoolUsed: 0, taxableProfit: 0, tax: 0, endingLossPool: post(opening + Math.abs(pbt)) };
  }
  const lossPoolUsed = post(Math.min(opening, pbt));
  const taxableProfit = post(Math.max(0, pbt - lossPoolUsed));
  const tax = post(taxableProfit * Math.max(0, taxRate));
  return { lossPoolUsed, taxableProfit, tax, endingLossPool: post(opening - lossPoolUsed) };
}
