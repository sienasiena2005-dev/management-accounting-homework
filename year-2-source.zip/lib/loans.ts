import type { ExistingLoan, LoanResult } from "../types/model.ts";
import { post } from "./rounding.ts";

export function calculateLoans(existingLoans: ExistingLoan[], borrowingAmount: number, loanTerm: number, newLoanRate: number): LoanResult {
  let principalRepaid = 0;
  let interest = 0;
  let endingDebt = 0;

  for (const loan of existingLoans) {
    const principal = post(Math.max(0, loan.outstandingPrincipal));
    const scheduled = loan.scheduledPrincipalPayment > 0
      ? loan.scheduledPrincipalPayment
      : principal / Math.max(1, loan.remainingTerm);
    const repayment = post(Math.min(principal, scheduled));
    principalRepaid += repayment;
    interest += post(principal * Math.max(0, loan.interestRate));
    endingDebt += post(principal - repayment);
  }

  const received = post(Math.max(0, borrowingAmount));
  if (received > 0) {
    const newPrincipal = post(received / Math.max(1, loanTerm));
    principalRepaid += Math.min(received, newPrincipal);
    interest += post(received * Math.max(0, newLoanRate));
    endingDebt += post(received - Math.min(received, newPrincipal));
  }

  return { received, principalRepaid: post(principalRepaid), interest: post(interest), endingDebt: post(endingDebt) };
}
