import { MARKET_FORECAST, YEAR1_REFERENCE } from "../data/year1Reference.ts";
import type { HistoricalPosition, ScenarioInput } from "../types/model.ts";
import { post } from "./rounding.ts";

export type ValidationFacts = {
  milkCapacity: number;
  machineCapacity: number;
  machineCount: number;
  machineSlots: number;
  premiseProduction: number;
};

export function validateScenario(input: ScenarioInput, history: HistoricalPosition, facts: ValidationFacts): string[] {
  const warnings: string[] = [];
  if (input.actualAllocation > input.plannedProduction) warnings.push("Actual trainer allocation exceeds planned production.");
  if (input.actualAllocation > input.requestedSales) warnings.push("Actual trainer allocation exceeds requested sales.");
  if (input.actualAllocation > MARKET_FORECAST) warnings.push("Actual trainer allocation exceeds the total market forecast.");
  if (input.plannedProduction > facts.milkCapacity) warnings.push("Planned production exceeds milk yield capacity.");
  if (input.plannedProduction > facts.machineCapacity) warnings.push("Planned production exceeds active machine capacity.");
  if (facts.machineCount > facts.machineSlots) warnings.push("Machines used exceed the selected premises’ machine slots.");
  if (post(facts.premiseProduction) !== post(input.plannedProduction)) warnings.push("Production assigned to premises does not equal planned production.");
  if (input.requestedSales % YEAR1_REFERENCE.requestedSalesBlock !== 0) warnings.push("Requested sales are not in 10,000-unit blocks under the Year 1 reference rule.");
  if (input.milkTons > 0 && input.milkTons < YEAR1_REFERENCE.minimumMilkTons) warnings.push("Milk purchase is below the Year 1 reference minimum of 1 ton.");
  if (input.marketInvestment > 0 && input.marketInvestment < YEAR1_REFERENCE.minimumMarketInvestment) warnings.push("Market investment is below the Year 1 reference minimum of Sh 1,000.");
  if (!input.premises.some((premise) => premise.selected)) warnings.push("Select at least one premise.");
  if (!history.machinesConfirmed) warnings.push("Year 1 machine ownership has not been confirmed.");
  if (!history.loansConfirmed) warnings.push("Year 1 outstanding loans have not been confirmed.");
  return warnings;
}
