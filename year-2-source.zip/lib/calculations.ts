import type { HistoricalPosition, ScenarioInput, ScenarioResult } from "../types/model.ts";
import { calculateLoans } from "./loans.ts";
import { nonNegative, post } from "./rounding.ts";
import { calculateTax } from "./tax.ts";
import { allocateTransport } from "./transport.ts";
import { validateScenario } from "./validation.ts";

type CoreResult = Omit<ScenarioResult, "breakEvenSalesAllocation" | "minimumAllocationForNonNegativeCash">;

function calculateCore(input: ScenarioInput, history: HistoricalPosition, actualSalesOverride?: number): CoreResult {
  const testedAllocation = post(nonNegative(actualSalesOverride ?? input.actualAllocation));
  const milkCapacity = post(nonNegative(input.milkTons) * nonNegative(input.milkYieldPerTon));
  const usedOwned = history.machines.filter((machine) =>
    input.usedOwnedMachineIds.includes(machine.instanceId) && machine.available && machine.remainingLife > 0,
  );
  const usedPurchases = input.machinePurchases.filter((machine) => machine.used);
  const depreciatingOwned = history.machines.filter((machine) => machine.remainingLife > 0);
  const machineCapacity = post(
    usedOwned.reduce((sum, machine) => sum + machine.capacity, 0) +
      usedPurchases.reduce((sum, machine) => sum + machine.capacity, 0),
  );
  const machineCountUsed = usedOwned.length + usedPurchases.length;
  const selectedPremises = input.premises.filter((premise) => premise.selected);
  const machineSlots = selectedPremises.reduce((sum, premise) => sum + premise.machineSlots, 0);
  const premiseProduction = selectedPremises.reduce((sum, premise) => sum + nonNegative(premise.production), 0);
  const transportAllocation = allocateTransport(input.premises, testedAllocation);
  const transport = post(transportAllocation.reduce((sum, row) => sum + row.cost, 0));
  const rent = post(selectedPremises.reduce((sum, premise) => sum + post(nonNegative(premise.rent)), 0));

  const revenue = post(testedAllocation * nonNegative(input.sellingPrice));
  const milkCost = post(nonNegative(input.milkTons) * nonNegative(input.milkCostPerTon));
  const maintenance = post(
    usedOwned.reduce((sum, machine) => sum + post(machine.maintenance), 0) +
      usedPurchases.reduce((sum, machine) => sum + post(machine.maintenance), 0),
  );
  const depreciation = post(
    depreciatingOwned.reduce((sum, machine) => sum + post(machine.depreciation), 0) +
      input.machinePurchases.reduce((sum, machine) => sum + post(machine.depreciation), 0),
  );
  const grossProfit = post(revenue - milkCost - maintenance - depreciation);
  const marketInvestment = post(nonNegative(input.marketInvestment));
  const employeeBonus = post(Math.max(0, grossProfit) * nonNegative(input.bonusRate));
  const fixedSalaries = post(nonNegative(input.fixedSalaries));
  const loans = calculateLoans(history.loans, input.borrowingAmount, input.loanTerm, input.interestRate);
  const profitBeforeTax = post(
    grossProfit - transport - marketInvestment - employeeBonus - fixedSalaries - rent - loans.interest,
  );
  const openingLossPool = history.taxLossCarryforward ?? 0;
  const taxes = calculateTax(profitBeforeTax, openingLossPool, input.taxRate);
  const netProfit = post(profitBeforeTax - taxes.tax);

  const openingCash = post(history.closingCash ?? 0);
  const machinePurchases = post(
    input.machinePurchases.reduce((sum, machine) => sum + post(nonNegative(machine.purchasePrice)), 0),
  );
  const cashBeforeAdvancePayments = post(
    openingCash + loans.received - machinePurchases - milkCost - marketInvestment,
  );
  const closingCash = post(
    openingCash + loans.received + revenue - machinePurchases - milkCost - marketInvestment - rent -
      maintenance - transport - fixedSalaries - employeeBonus - loans.principalRepaid - loans.interest - taxes.tax,
  );

  const unusedMilk = post(Math.max(0, milkCapacity - nonNegative(input.plannedProduction)));
  const unsoldIceCream = post(Math.max(0, nonNegative(input.plannedProduction) - testedAllocation));
  const spoilageExposure = post(unusedMilk + unsoldIceCream);
  const warnings = validateScenario(input, history, {
    milkCapacity,
    machineCapacity,
    machineCount: machineCountUsed,
    machineSlots,
    premiseProduction,
  });
  if (cashBeforeAdvancePayments < 0) warnings.unshift("Cash is negative before required advance payments.");
  if (closingCash < 0) warnings.unshift("Closing cash is negative.");

  const missingHistory: string[] = [];
  if (history.closingCash === null) missingHistory.push("Closing cash after Autumn");
  if (history.annualNetProfit === null) missingHistory.push("Year 1 annual net profit");
  if (history.taxLossCarryforward === null) missingHistory.push("Tax-loss carryforward");
  if (!history.loansConfirmed) missingHistory.push("Outstanding loans confirmation");
  if (!history.machinesConfirmed) missingHistory.push("Owned machines confirmation");

  return {
    testedAllocation,
    revenue,
    milkCost,
    maintenance,
    depreciation,
    grossProfit,
    transport,
    marketInvestment,
    employeeBonus,
    fixedSalaries,
    rent,
    loanInterest: loans.interest,
    profitBeforeTax,
    taxLossPoolUsed: taxes.lossPoolUsed,
    taxableProfit: taxes.taxableProfit,
    tax: taxes.tax,
    netProfit,
    endingTaxLossCarryforward: taxes.endingLossPool,
    openingCash,
    newBorrowing: loans.received,
    machinePurchases,
    loanPrincipal: loans.principalRepaid,
    cashBeforeAdvancePayments,
    closingCash,
    endingDebt: loans.endingDebt,
    unitsSold: testedAllocation,
    unsoldIceCream,
    unusedMilk,
    spoilageExposure,
    activeMachineCapacity: machineCapacity,
    machineCountUsed,
    machineSlots,
    transportAllocation,
    warnings,
    missingHistory,
  };
}

function findMinimumAllocation(
  input: ScenarioInput,
  history: HistoricalPosition,
  predicate: (result: CoreResult) => boolean,
): number | null {
  const maximum = post(nonNegative(input.plannedProduction));
  if (predicate(calculateCore(input, history, 0))) return 0;
  if (maximum <= 0 || !predicate(calculateCore(input, history, maximum))) return null;
  let low = 0;
  let high = maximum;
  while (low < high) {
    const mid = Math.floor((low + high) / 2);
    if (predicate(calculateCore(input, history, mid))) high = mid;
    else low = mid + 1;
  }
  return low;
}

export function calculateScenario(
  input: ScenarioInput,
  history: HistoricalPosition,
  allocationPercent = 100,
): ScenarioResult {
  const testedAllocation = post(nonNegative(input.actualAllocation) * Math.max(0, allocationPercent) / 100);
  const core = calculateCore(input, history, testedAllocation);
  return {
    ...core,
    breakEvenSalesAllocation: findMinimumAllocation(input, history, (result) => result.netProfit >= 0),
    minimumAllocationForNonNegativeCash: history.closingCash === null
      ? null
      : findMinimumAllocation(input, history, (result) => result.closingCash >= 0),
  };
}

export function calculateTradeoff(a: ScenarioResult, b: ScenarioResult, aName: string, bName: string): string {
  const revenueDifference = post(b.revenue - a.revenue);
  const allocationDifference = post(b.unitsSold - a.unitsSold);
  const workingCapitalA = post(a.openingCash + a.newBorrowing - a.cashBeforeAdvancePayments);
  const workingCapitalB = post(b.openingCash + b.newBorrowing - b.cashBeforeAdvancePayments);
  const workingCapitalDifference = post(workingCapitalB - workingCapitalA);
  const direction = revenueDifference >= 0 ? "more" : "less";
  const allocationDirection = allocationDifference >= 0 ? "additional" : "fewer";
  const capitalDirection = workingCapitalDifference >= 0 ? "more" : "less";
  return `${bName} generates Sh ${Math.abs(revenueDifference).toLocaleString()} ${direction} revenue because it tests ${Math.abs(allocationDifference).toLocaleString()} ${allocationDirection} units of trainer allocation than ${aName}. It requires Sh ${Math.abs(workingCapitalDifference).toLocaleString()} ${capitalDirection} advance working capital and carries ${b.spoilageExposure.toLocaleString()} equivalent units of downside exposure at the tested allocation.`;
}
