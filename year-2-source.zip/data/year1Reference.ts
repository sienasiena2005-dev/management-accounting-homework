import type { MachineReference, PremiseReference } from "../types/model.ts";

export const MARKET_FORECAST = 410_000;
export const MACHINE_LIFE_SEASONS = 8;

export const PREMISE_REFERENCES: PremiseReference[] = [
  { id: "A", machineSlots: 1, rent: 12_000, transportRate: 0.3, possibleStorage: true },
  { id: "B", machineSlots: 1, rent: 10_000, transportRate: 0.4, possibleStorage: true },
  { id: "C", machineSlots: 1, rent: 12_000, transportRate: 0.3, possibleStorage: false },
  { id: "D", machineSlots: 1, rent: 17_000, transportRate: 0.1, possibleStorage: false },
  { id: "E", machineSlots: 2, rent: 15_000, transportRate: 0.2, possibleStorage: false },
  { id: "F", machineSlots: 3, rent: 16_000, transportRate: 0.2, possibleStorage: true },
];

export const MACHINE_REFERENCES: MachineReference[] = [
  { id: "machine-1", name: "Machine 1", capacity: 72_000, purchasePrice: 35_000, maintenance: 1_800, depreciation: 4_375 },
  { id: "machine-2", name: "Machine 2", capacity: 120_000, purchasePrice: 95_000, maintenance: 2_900, depreciation: 11_875 },
  { id: "machine-3", name: "Machine 3", capacity: 68_000, purchasePrice: 38_000, maintenance: 2_100, depreciation: 4_750 },
  { id: "machine-4", name: "Machine 4", capacity: 95_000, purchasePrice: 70_000, maintenance: 2_900, depreciation: 8_750 },
  { id: "machine-5", name: "Machine 5", capacity: 45_000, purchasePrice: 28_000, maintenance: 1_300, depreciation: 3_500 },
  { id: "machine-6", name: "Machine 6", capacity: 110_000, purchasePrice: 90_000, maintenance: 2_900, depreciation: 11_250 },
];

export const YEAR1_REFERENCE = {
  requestedSalesBlock: 10_000,
  minimumMilkTons: 1,
  minimumMarketInvestment: 1_000,
  bonusRate: 0.05,
  taxRate: 0.1,
  loanInterestRate: 0.1,
};
