import type { HistoricalPosition } from "../types/model.ts";

export const EMPTY_STUDENT_STARTING_POSITION: HistoricalPosition = {
  closingCash: null,
  annualNetProfit: null,
  taxLossCarryforward: null,
  loansConfirmed: false,
  machinesConfirmed: false,
  loans: [],
  machines: [],
};
